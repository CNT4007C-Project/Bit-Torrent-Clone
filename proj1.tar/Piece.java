public class Piece {

    private int pieceSize = peerProcess.getPieceSize();
    private byte[] pieceBytes = new byte[pieceSize];
    
    public Piece(){
        
    }
}
